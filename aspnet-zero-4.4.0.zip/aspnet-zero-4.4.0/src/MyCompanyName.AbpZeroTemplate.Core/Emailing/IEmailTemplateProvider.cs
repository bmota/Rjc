﻿namespace MyCompanyName.AbpZeroTemplate.Emailing
{
    public interface IEmailTemplateProvider
    {
        string GetDefaultTemplate(int? tenantId);
    }
}
