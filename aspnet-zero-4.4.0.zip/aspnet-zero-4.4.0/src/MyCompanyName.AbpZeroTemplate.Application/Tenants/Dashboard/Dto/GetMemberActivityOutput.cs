﻿using System.Collections.Generic;

namespace MyCompanyName.AbpZeroTemplate.Tenants.Dashboard.Dto
{
    public class GetMemberActivityOutput
    {
        public List<int> TotalMembers { get; set; }

        public List<int> NewMembers { get; set; }
    }
}