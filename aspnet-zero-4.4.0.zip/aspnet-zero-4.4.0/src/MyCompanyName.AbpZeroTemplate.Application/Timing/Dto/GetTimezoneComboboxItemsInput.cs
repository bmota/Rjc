﻿using Abp.Configuration;

namespace MyCompanyName.AbpZeroTemplate.Timing.Dto
{
    public class GetTimezoneComboboxItemsInput
    {
        public SettingScopes DefaultTimezoneScope;

        public string SelectedTimezoneId { get; set; }
    }
}
