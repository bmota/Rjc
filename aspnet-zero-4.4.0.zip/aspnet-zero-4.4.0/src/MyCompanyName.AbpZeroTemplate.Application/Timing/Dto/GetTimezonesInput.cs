﻿using Abp.Configuration;

namespace MyCompanyName.AbpZeroTemplate.Timing.Dto
{
    public class GetTimezonesInput
    {
        public SettingScopes DefaultTimezoneScope;
    }
}
