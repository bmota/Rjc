﻿namespace MyCompanyName.AbpZeroTemplate.Auditing
{
    public interface INamespaceStripper
    {
        string StripNameSpace(string serviceName);
    }
}