﻿using System.Collections.Generic;

namespace MyCompanyName.AbpZeroTemplate.Logging.Dto
{
    public class GetLatestWebLogsOutput
    {
        public List<string> LatesWebLogLines { get; set; }
    }
}
