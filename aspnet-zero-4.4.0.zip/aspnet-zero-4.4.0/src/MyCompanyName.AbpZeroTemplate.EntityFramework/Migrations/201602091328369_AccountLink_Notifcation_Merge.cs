namespace MyCompanyName.AbpZeroTemplate.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class AccountLink_Notifcation_Merge : DbMigration
    {
        public override void Up()
        {
            
        }
        
        public override void Down()
        {
            
        }
    }
}
